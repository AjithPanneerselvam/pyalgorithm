Why code? when it is availabe.


